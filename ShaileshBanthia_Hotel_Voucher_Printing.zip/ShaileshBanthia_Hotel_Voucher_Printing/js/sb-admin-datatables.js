// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#hotel_list').DataTable();
});
